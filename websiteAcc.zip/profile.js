// ============================================================
// PaperCraft Account — profile.js
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    const user = PCAuth.getUser();
    const gate    = document.getElementById('authGate');
    const content = document.getElementById('dashboardContent');

    if (!user) {
        gate.hidden = false;
        content.style.display = 'none';
        return;
    }

    gate.hidden = true;

    // Populate header
    document.getElementById('profileUsername').textContent = user.username || 'Player';
    document.getElementById('profileEmail').textContent    = user.email    || '';
    document.getElementById('joinDate').textContent =
        new Date(user.joinDate || Date.now()).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });

    // Load stats from localStorage
    const accounts = JSON.parse(localStorage.getItem('pcAccounts') || '[]');
    const fullUser = accounts.find(a => a.uuid === user.uuid);
    if (fullUser && fullUser.stats) {
        const s = fullUser.stats;
        const fmt = n => n >= 1000 ? (n/1000).toFixed(1)+'K' : n;
        document.getElementById('stat-blocks').textContent  = fmt(s.blocksMined  || 0);
        document.getElementById('stat-placed').textContent  = fmt(s.blocksPlaced || 0);
        document.getElementById('stat-kills').textContent   = fmt(s.kills        || 0);
        document.getElementById('stat-deaths').textContent  = fmt(s.deaths       || 0);
        document.getElementById('stat-worlds').textContent  = fmt(s.worlds       || 0);
        document.getElementById('stat-time').textContent    = (s.playtime || 0)  + 'h';
    }

    // Load saved skin
    const savedSkin = localStorage.getItem('playerSkin');
    if (savedSkin) applyAvatarSkin(savedSkin);

    // --- Skin upload ---
    const skinUpload  = document.getElementById('skinUpload');
    const changeSkinBtn = document.getElementById('changeSkinBtn');
    const skinModal   = document.getElementById('skinModal');
    const skinDropArea= document.getElementById('skinDropArea');
    const skinFileInput=document.getElementById('skinFileInput');
    const applySkinBtn= document.getElementById('applySkin');
    const cancelSkin  = document.getElementById('cancelSkin');
    const closeSkinModal=document.getElementById('closeSkinModal');
    const clearSkinBtn= document.getElementById('clearSkinBtn');

    let pendingSkin = null;

    changeSkinBtn?.addEventListener('click', () => { skinModal.hidden = false; });
    [cancelSkin, closeSkinModal].forEach(el => el?.addEventListener('click', () => { skinModal.hidden = true; pendingSkin = null; applySkinBtn.disabled = true; }));

    skinDropArea?.addEventListener('dragover', e => { e.preventDefault(); skinDropArea.classList.add('drag-over'); });
    skinDropArea?.addEventListener('dragleave', () => skinDropArea.classList.remove('drag-over'));
    skinDropArea?.addEventListener('drop', e => {
        e.preventDefault();
        skinDropArea.classList.remove('drag-over');
        const file = e.dataTransfer.files[0];
        if (file) readSkinFile(file);
    });
    skinFileInput?.addEventListener('change', () => {
        if (skinFileInput.files[0]) readSkinFile(skinFileInput.files[0]);
    });

    function readSkinFile(file) {
        if (!file.type.includes('png')) {
            showToast('Please upload a PNG file.', 'error'); return;
        }
        const reader = new FileReader();
        reader.onload = e => {
            pendingSkin = e.target.result;
            applySkinBtn.disabled = false;
            skinDropArea.innerHTML = `<img src="${pendingSkin}" style="width:64px;height:64px;image-rendering:pixelated;border:2px solid var(--border2)"><p>Skin ready to apply</p>`;
        };
        reader.readAsDataURL(file);
    }

    applySkinBtn?.addEventListener('click', () => {
        if (!pendingSkin) return;
        localStorage.setItem('playerSkin', pendingSkin);
        applyAvatarSkin(pendingSkin);
        skinModal.hidden = true;
        pendingSkin = null;
        showToast('Skin applied!', 'success');
    });

    clearSkinBtn?.addEventListener('click', () => {
        localStorage.removeItem('playerSkin');
        document.getElementById('profileAvatar').innerHTML = '<div class="avatar-skin"><div class="sk-head"></div><div class="sk-body"></div><div class="sk-leg left"></div><div class="sk-leg right"></div></div>';
        showToast('Skin reset to default.', 'default');
    });

    function applyAvatarSkin(dataUrl) {
        const fig = document.getElementById('skinFigure');
        if (fig) {
            // simple tinted overlay with the skin
            fig.style.filter = 'none';
        }
    }

    // --- Worlds (from localStorage saved worlds) ---
    refreshWorldsList();

    document.getElementById('newWorldBtn')?.addEventListener('click', () => {
        window.location.href = '../game.html';
    });

    function refreshWorldsList() {
        const list   = document.getElementById('worldsList');
        const savedRaw = localStorage.getItem('worlds');
        const worlds = savedRaw ? JSON.parse(savedRaw) : [];

        // Remove demo items
        list.querySelectorAll('.world-item').forEach(el => el.remove());

        if (worlds.length === 0) {
            document.getElementById('worldsEmpty').hidden = false;
            return;
        }
        document.getElementById('worldsEmpty').hidden = true;

        worlds.slice().reverse().forEach(w => {
            const div = document.createElement('div');
            div.className = 'world-item';
            div.innerHTML = `
                <div class="world-thumb">
                    <div class="wt-grass"></div>
                    <div class="wt-dirt"></div>
                    <div class="wt-stone"></div>
                </div>
                <div class="world-info">
                    <div class="world-name">${escHtml(w.name || 'World')}</div>
                    <div class="world-meta">Last played ${relativeDate(w.lastPlayed)}</div>
                </div>
                <div class="world-actions">
                    <button class="wa-btn play" title="Play" data-id="${w.id}">▶</button>
                    <button class="wa-btn del"  title="Delete" data-id="${w.id}">✕</button>
                </div>`;
            list.insertBefore(div, list.firstChild);
        });

        // Event delegation
        list.addEventListener('click', e => {
            const btn = e.target.closest('.wa-btn');
            if (!btn) return;
            const id = parseInt(btn.dataset.id);
            if (btn.classList.contains('play')) {
                localStorage.setItem('selectedWorld', JSON.stringify({ id, name: '' }));
                window.location.href = '../game.html';
            } else if (btn.classList.contains('del')) {
                if (!confirm('Delete this world?')) return;
                const list = JSON.parse(localStorage.getItem('worlds') || '[]');
                localStorage.setItem('worlds', JSON.stringify(list.filter(w => w.id !== id)));
                localStorage.removeItem(String(id));
                refreshWorldsList();
                showToast('World deleted.', 'default');
            }
        });
    }
});

function escHtml(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function relativeDate(iso) {
    if (!iso) return 'Never';
    const diff = (Date.now() - new Date(iso).getTime()) / 1000;
    if (diff < 60)   return 'Just now';
    if (diff < 3600) return Math.floor(diff/60) + ' min ago';
    if (diff < 86400)return Math.floor(diff/3600) + ' hours ago';
    return Math.floor(diff/86400) + ' days ago';
}
