// ============================================================
// PaperCraft Account — main.js
// ============================================================

// --- Pixel Particles ---
(function initParticles() {
    const container = document.getElementById('particles');
    if (!container) return;

    const colors = ['#3b82f6', '#60a5fa', '#22d3ee', '#38bdf8', '#1d4ed8'];
    const count = 24;

    for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.cssText = `
            left: ${Math.random() * 100}%;
            top: ${-Math.random() * 20}%;
            width: ${Math.random() < 0.5 ? 4 : 6}px;
            height: ${Math.random() < 0.5 ? 4 : 6}px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            animation-duration: ${8 + Math.random() * 16}s;
            animation-delay: ${-Math.random() * 20}s;
            opacity: ${0.2 + Math.random() * 0.4};
        `;
        container.appendChild(p);
    }
})();

// --- Active nav link highlight ---
(function highlightNav() {
    const path = window.location.pathname;
    const links = document.querySelectorAll('.nav-link');
    links.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') && path.endsWith(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
})();

// --- Sign Out ---
const signOutBtn = document.getElementById('signOutBtn');
if (signOutBtn) {
    signOutBtn.addEventListener('click', () => {
        localStorage.removeItem('pcUser');
        window.location.href = 'login.html';
    });
}

// --- Simple fake auth store (localStorage) ---
window.PCAuth = {
    getUser() {
        try {
            const raw = localStorage.getItem('pcUser');
            return raw ? JSON.parse(raw) : null;
        } catch { return null; }
    },
    setUser(user) {
        localStorage.setItem('pcUser', JSON.stringify(user));
    },
    signOut() {
        localStorage.removeItem('pcUser');
    },
    isLoggedIn() {
        return !!this.getUser();
    }
};

// --- Utility: show toast ---
window.showToast = function(message, type = 'default') {
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = `toast ${type}`;
    // Force reflow
    toast.offsetHeight;
    toast.classList.add('show');
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
};
