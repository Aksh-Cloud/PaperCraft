// ============================================================
// PaperCraft Account — auth.js (login + signup)
// ============================================================

// --- Password toggle ---
document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', () => {
        const input = btn.previousElementSibling;
        const isPass = input.type === 'password';
        input.type = isPass ? 'text' : 'password';
        btn.querySelector('.eye-open').style.display  = isPass ? 'none' : '';
        btn.querySelector('.eye-closed').style.display = isPass ? '' : 'none';
    });
});

// --- Password strength (signup only) ---
const pwField = document.getElementById('password');
const strengthFill = document.getElementById('strengthFill');
const strengthLabel = document.getElementById('strengthLabel');

function getStrength(pw) {
    let score = 0;
    if (pw.length >= 8)  score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    return score;
}

if (pwField && strengthFill && strengthLabel) {
    pwField.addEventListener('input', () => {
        const pw = pwField.value;
        if (!pw) {
            strengthFill.className = 'strength-fill';
            strengthLabel.textContent = 'Enter password';
            return;
        }
        const s = getStrength(pw);
        const levels = [
            { cls: '', label: '' },
            { cls: 'w25', label: 'Very weak' },
            { cls: 'w50', label: 'Weak' },
            { cls: 'w75', label: 'Good' },
            { cls: 'w75', label: 'Strong' },
            { cls: 'w100', label: 'Very strong' },
        ];
        const level = levels[Math.min(s, 5)];
        strengthFill.className = `strength-fill ${level.cls}`;
        strengthLabel.textContent = level.label;
    });
}

// --- Validate helpers ---
function showError(id, msg) {
    const el = document.getElementById(id);
    if (el) el.textContent = msg;
}
function clearError(id) {
    const el = document.getElementById(id);
    if (el) el.textContent = '';
}
function setFormError(msg) {
    const el = document.getElementById('formError');
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('visible', !!msg);
}

// ============================================================
// LOGIN FORM
// ============================================================
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        clearError('emailError'); clearError('passwordError'); setFormError('');

        const email    = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const remember = document.getElementById('remember').checked;
        let valid = true;

        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showError('emailError', 'Enter a valid email address.'); valid = false;
        }
        if (!password) {
            showError('passwordError', 'Enter your password.'); valid = false;
        }
        if (!valid) return;

        // Simulate loading
        setLoading(true);
        await fakeDelay(900);

        // Check against stored accounts
        const accounts = JSON.parse(localStorage.getItem('pcAccounts') || '[]');
        const match = accounts.find(a => a.email === email && a.password === btoa(password));

        if (!match) {
            setLoading(false);
            setFormError('Incorrect email or password. Please try again.');
            return;
        }

        // Store session
        PCAuth.setUser({
            uuid: match.uuid,
            username: match.username,
            email: match.email,
            joinDate: match.joinDate,
        });

        if (!remember) {
            // Mark as session-only (we'll check this in profile)
            sessionStorage.setItem('pcSession', 'true');
        }

        setLoading(false);
        window.location.href = 'profile.html';
    });

    function setLoading(on) {
        const btn  = document.getElementById('submitBtn');
        const text = btn.querySelector('.btn-text');
        const load = btn.querySelector('.btn-loader');
        btn.disabled = on;
        text.style.display = on ? 'none' : '';
        load.hidden = !on;
    }
}

// ============================================================
// SIGNUP FORM
// ============================================================
const signupForm = document.getElementById('signupForm');
if (signupForm) {
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        ['usernameError','emailError','passwordError','confirmPasswordError','termsError']
            .forEach(id => clearError(id));
        setFormError('');

        const username = document.getElementById('username').value.trim();
        const email    = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const confirm  = document.getElementById('confirmPassword').value;
        const terms    = document.getElementById('terms').checked;
        let valid = true;

        if (!username || username.length < 3 || username.length > 15 || !/^[a-zA-Z0-9_]+$/.test(username)) {
            showError('usernameError', 'Username must be 3–15 letters, numbers or underscores.'); valid = false;
        }
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showError('emailError', 'Enter a valid email address.'); valid = false;
        }
        if (!password || getStrength(password) < 2) {
            showError('passwordError', 'Password is too weak. Use at least 8 characters.'); valid = false;
        }
        if (password !== confirm) {
            showError('confirmPasswordError', 'Passwords do not match.'); valid = false;
        }
        if (!terms) {
            showError('termsError', 'You must agree to the Terms of Service.'); valid = false;
        }
        if (!valid) return;

        setLoading(true);
        await fakeDelay(1000);

        // Check for duplicate email/username
        const accounts = JSON.parse(localStorage.getItem('pcAccounts') || '[]');
        if (accounts.some(a => a.email === email)) {
            setLoading(false);
            showError('emailError', 'An account with this email already exists.');
            return;
        }
        if (accounts.some(a => a.username.toLowerCase() === username.toLowerCase())) {
            setLoading(false);
            showError('usernameError', 'This username is already taken.');
            return;
        }

        // Create account
        const newUser = {
            uuid: crypto.randomUUID(),
            username,
            email,
            password: btoa(password), // very basic — not for production
            joinDate: new Date().toISOString(),
            stats: { blocksMined:0, blocksPlaced:0, kills:0, deaths:0, worlds:0, playtime:0 },
        };
        accounts.push(newUser);
        localStorage.setItem('pcAccounts', JSON.stringify(accounts));

        // Auto sign in
        PCAuth.setUser({
            uuid: newUser.uuid,
            username: newUser.username,
            email: newUser.email,
            joinDate: newUser.joinDate,
        });

        setLoading(false);
        window.location.href = 'profile.html';
    });

    function setLoading(on) {
        const btn  = document.getElementById('submitBtn');
        const text = btn.querySelector('.btn-text');
        const load = btn.querySelector('.btn-loader');
        btn.disabled = on;
        text.style.display = on ? 'none' : '';
        load.hidden = !on;
    }
}

function fakeDelay(ms) {
    return new Promise(res => setTimeout(res, ms));
}
